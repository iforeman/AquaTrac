# /Users/ian/Documents/Dev/aquatrac/models/fish.py

from app import db


class Fish(db.Model):
    __tablename__ = 'fish'

    id = db.Column(db.Integer, primary_key=True)
    aquarium_id = db.Column(db.Integer, db.ForeignKey('aquariums.id'), nullable=False)
    scientific_name = db.Column(db.String(150))
    common_name = db.Column(db.String(150))
    species = db.Column(db.String(150))
    origin = db.Column(db.String(150))
    quantity = db.Column(db.Integer)
    max_size = db.Column(db.Float)
    min_tank_size = db.Column(db.Float)
    min_temp = db.Column(db.Float)
    max_temp = db.Column(db.Float)
    kh_min = db.Column(db.Float)
    kh_max = db.Column(db.Float)
    ph_min = db.Column(db.Float)
    ph_max = db.Column(db.Float)
    species_information = db.Column(db.Text)
    aquarium_care = db.Column(db.Text)
    feeding_nutrition = db.Column(db.Text)
    diet = db.Column(db.Enum('Omnivore', 'Carnivore', 'Herbivore'))
    aquarium_type = db.Column(db.String(150))
    care_level = db.Column(db.Enum('Easy', 'Moderate', 'Intermediate to Expert', 'Expert'))
    temperament = db.Column(db.Enum('Peaceful', 'Semi-aggressive', 'Aggressive'))
    purchase_date = db.Column(db.Date)
    unit_price = db.Column(db.Float)
    store_id = db.Column(db.Integer)
    death_date = db.Column(db.Date)
    sale_date = db.Column(db.Date)
    sale_price = db.Column(db.Float)
    birth_date = db.Column(db.Date)
    father_fish_id = db.Column(db.Integer)
    mother_fish_id = db.Column(db.Integer)
    picture = db.Column(db.String(150))

    aquarium = db.relationship('Aquarium', backref='fish')

    def __repr__(self):
        return f'<Fish {self.common_name}>'
