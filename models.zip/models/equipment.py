# /Users/ian/Documents/Dev/aquatrac/models/equipment.py

from app import db


class Equipment(db.Model):
    __tablename__ = 'equipment'

    id = db.Column(db.Integer, primary_key=True)
    aquarium_id = db.Column(db.Integer, db.ForeignKey('aquariums.id'), nullable=False)
    type = db.Column(db.Enum('Filter', 'Light', 'Pump', 'Heater', 'Other'))
    performance_lph = db.Column(db.Float)
    model = db.Column(db.String(150))
    setup_date = db.Column(db.Date)
    purchase_date = db.Column(db.Date)
    store_id = db.Column(db.Integer)
    unit_price = db.Column(db.Float)
    quantity = db.Column(db.Integer)
    total = db.Column(db.Float)
    power_input = db.Column(db.Enum('220v', '110v'))
    power_consumption = db.Column(db.Float)
    run_time_duration = db.Column(db.Float)
    maintenance_interval = db.Column(db.Integer)
    maintenance_week_day = db.Column(db.String(50))
    replacement_interval = db.Column(db.Integer)
    replacement_week_day = db.Column(db.String(50))

    aquarium = db.relationship('Aquarium', backref='equipment')

    def __repr__(self):
        return f'<Equipment {self.model}>'
