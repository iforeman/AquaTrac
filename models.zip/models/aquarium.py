# /Users/ian/Documents/Dev/aquatrac/models/aquarium.py

from app import db
from models.user import User  # Ensure User is imported

class Aquarium(db.Model):
    __tablename__ = 'aquariums'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    model = db.Column(db.String(150))
    tank_type = db.Column(
        db.Enum('Community', 'Species', 'Cichlid', 'Biotype', 'Breeding', 'Planted', 'Shrimp', 'Fish-only',
                'Coldwater'), nullable=False)
    shape = db.Column(
        db.Enum('Cube/Rectangular', 'Bow-Front', 'Hexagonal', 'Cylinder', 'L-shaped', 'Pentagon', 'Column'),
        nullable=False)
    length = db.Column(db.Float)
    width = db.Column(db.Float)
    depth = db.Column(db.Float)
    capacity = db.Column(db.Float)
    substrate = db.Column(
        db.Enum('Gravel', 'Sand', 'Planted tank substrates', 'Clay-based substrates', 'Rocks', 'Fluorite', 'None'),
        nullable=False)
    setup_date = db.Column(db.Date)
    price = db.Column(db.Float)
    store_id = db.Column(db.Integer, db.ForeignKey('stores.id'))
    picture = db.Column(db.String(150))

    user = db.relationship('User', backref='aquariums')

    def __repr__(self):
        return f'<Aquarium {self.name}>'
