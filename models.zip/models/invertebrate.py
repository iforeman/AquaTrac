# /Users/ian/Documents/Dev/aquatrac/models/invertebrate.py

from app import db


class Invertebrate(db.Model):
    __tablename__ = 'invertebrates'

    id = db.Column(db.Integer, primary_key=True)
    aquarium_id = db.Column(db.Integer, db.ForeignKey('aquariums.id'), nullable=False)
    scientific_name = db.Column(db.String(150))
    common_name = db.Column(db.String(150))
    species = db.Column(db.String(150))
    family = db.Column(db.String(150))
    sub_family = db.Column(db.String(150))
    max_size = db.Column(db.Float)
    min_tank_size = db.Column(db.Float)
    min_temp = db.Column(db.Float)
    max_temp = db.Column(db.Float)
    kh_min = db.Column(db.Float)
    kh_max = db.Column(db.Float)
    ph_min = db.Column(db.Float)
    ph_max = db.Column(db.Float)
    origin = db.Column(db.String(150))
    quantity = db.Column(db.Integer)
    size = db.Column(db.Float)
    colour = db.Column(db.String(50))
    diet = db.Column(db.Enum('Omnivore', 'Carnivore', 'Herbivore'))
    aquarium_type = db.Column(db.String(150))
    temperament = db.Column(db.Enum('Peaceful', 'Semi-aggressive', 'Aggressive'))
    purchase_date = db.Column(db.Date)
    unit_price = db.Column(db.Float)
    store_id = db.Column(db.Integer)
    death_date = db.Column(db.Date)
    sale_date = db.Column(db.Date)
    sale_price = db.Column(db.Float)
    species_information = db.Column(db.Text)
    aquarium_care = db.Column(db.Text)
    feeding_nutrition = db.Column(db.Text)
    birth_date = db.Column(db.Date)
    birth_tank_id = db.Column(db.Integer)
    picture = db.Column(db.String(150))

    aquarium = db.relationship('Aquarium', backref='invertebrates')

    def __repr__(self):
        return f'<Invertebrate {self.common_name}>'
