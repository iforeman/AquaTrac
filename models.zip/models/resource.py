# /Users/ian/Documents/Dev/aquatrac/models/resource.py

from app import db


class Resource(db.Model):
    __tablename__ = 'resources'

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    title = db.Column(db.String(150))
    content = db.Column(db.Text)
    category = db.Column(db.String(100))
    author = db.Column(db.String(100))
    publish_date = db.Column(db.Date)

    def __repr__(self):
        return f'<Resource {self.title}>'
