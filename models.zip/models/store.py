# /Users/ian/Documents/Dev/aquatrac/models/store.py

from app import db


class Store(db.Model):
    __tablename__ = 'stores'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    address = db.Column(db.String(250))
    address2 = db.Column(db.String(250))
    postal_code = db.Column(db.String(20))
    city = db.Column(db.String(100))
    country = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    email = db.Column(db.String(150))
    website = db.Column(db.String(150))
    contact1 = db.Column(db.String(100))
    contact2 = db.Column(db.String(100))
    notes = db.Column(db.Text)
    visibility = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f'<Store {self.name}>'
