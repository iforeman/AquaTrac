# /Users/ian/Documents/Dev/aquatrac/models/task.py

from app import db


class Task(db.Model):
    __tablename__ = 'tasks'

    id = db.Column(db.Integer, primary_key=True)
    aquarium_id = db.Column(db.Integer, db.ForeignKey('aquariums.id'), nullable=False)
    description = db.Column(db.Text)
    due_date = db.Column(db.Date)
    completed = db.Column(db.Boolean, default=False)
    type = db.Column(db.String(100))
    interval = db.Column(db.Integer)
    week_day = db.Column(db.String(20))

    aquarium = db.relationship('Aquarium', backref='tasks')

    def __repr__(self):
        return f'<Task {self.description}>'
