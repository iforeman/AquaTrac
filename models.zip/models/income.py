# /Users/ian/Documents/Dev/aquatrac/models/income.py

from app import db


class Income(db.Model):
    __tablename__ = 'incomes'

    id = db.Column(db.Integer, primary_key=True)
    aquarium_id = db.Column(db.Integer, db.ForeignKey('aquariums.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    designation = db.Column(db.String(150))
    amount = db.Column(db.Float)
    notes = db.Column(db.Text)

    aquarium = db.relationship('Aquarium', backref='incomes')

    def __repr__(self):
        return f'<Income {self.designation}>'
