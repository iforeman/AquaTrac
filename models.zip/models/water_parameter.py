# /Users/ian/Documents/Dev/aquatrac/models/water_parameter.py

from app import db


class WaterParameter(db.Model):
    __tablename__ = 'water_parameters'

    id = db.Column(db.Integer, primary_key=True)
    aquarium_id = db.Column(db.Integer, db.ForeignKey('aquariums.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    temperature_min = db.Column(db.Float)
    temperature_max = db.Column(db.Float)
    ph_min = db.Column(db.Float)
    ph_max = db.Column(db.Float)
    gh_min = db.Column(db.Float)
    gh_max = db.Column(db.Float)
    kh_min = db.Column(db.Float)
    kh_max = db.Column(db.Float)
    nitrite_min = db.Column(db.Float)
    nitrite_max = db.Column(db.Float)
    nitrate_min = db.Column(db.Float)
    nitrate_max = db.Column(db.Float)
    ammonium_min = db.Column(db.Float)
    ammonium_max = db.Column(db.Float)
    copper_min = db.Column(db.Float)
    copper_max = db.Column(db.Float)
    oxygen_min = db.Column(db.Float)
    oxygen_max = db.Column(db.Float)
    conductivity_min = db.Column(db.Float)
    conductivity_max = db.Column(db.Float)
    phosphate_min = db.Column(db.Float)
    phosphate_max = db.Column(db.Float)
    iron_min = db.Column(db.Float)
    iron_max = db.Column(db.Float)
    co2_min = db.Column(db.Float)
    co2_max = db.Column(db.Float)
    chlorine_min = db.Column(db.Float)
    chlorine_max = db.Column(db.Float)

    aquarium = db.relationship('Aquarium', backref='water_parameters')

    def __repr__(self):
        return f'<WaterParameter {self.date}>'
