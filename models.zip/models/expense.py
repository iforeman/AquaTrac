# /Users/ian/Documents/Dev/aquatrac/models/expense.py

from app import db


class Expense(db.Model):
    __tablename__ = 'expenses'

    id = db.Column(db.Integer, primary_key=True)
    aquarium_id = db.Column(db.Integer, db.ForeignKey('aquariums.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    item = db.Column(db.String(150))
    category = db.Column(db.String(100))
    store_id = db.Column(db.Integer, db.ForeignKey('stores.id'))
    unit_price = db.Column(db.Float)
    quantity = db.Column(db.Integer)
    total = db.Column(db.Float)
    notes = db.Column(db.Text)

    aquarium = db.relationship('Aquarium', backref='expenses')

    def __repr__(self):
        return f'<Expense {self.item}>'
