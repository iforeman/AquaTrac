# /Users/ian/Documents/Dev/aquatrac/models/plant.py

from app import db


class Plant(db.Model):
    __tablename__ = 'plants'

    id = db.Column(db.Integer, primary_key=True)
    aquarium_id = db.Column(db.Integer, db.ForeignKey('aquariums.id'), nullable=False)
    scientific_name = db.Column(db.String(150))
    common_name = db.Column(db.String(150))
    family = db.Column(db.String(150))
    origin = db.Column(db.String(150))
    quantity = db.Column(db.Integer)
    max_size = db.Column(db.Float)
    height = db.Column(db.Float)
    colour = db.Column(db.String(50))
    care_level = db.Column(db.Enum('Easy', 'Moderate', 'Intermediate to Expert', 'Expert'))
    lighting = db.Column(db.Enum('Low', 'Medium', 'Medium to High', 'High'))
    placement = db.Column(db.Enum('Foreground', 'Midground', 'Midground to Background', 'Background', 'Floating'))
    purchase_date = db.Column(db.Date)
    min_temp = db.Column(db.Float)
    max_temp = db.Column(db.Float)
    kh_min = db.Column(db.Float)
    kh_max = db.Column(db.Float)
    ph_min = db.Column(db.Float)
    ph_max = db.Column(db.Float)
    unit_price = db.Column(db.Float)
    store_id = db.Column(db.Integer)
    multiplication_date = db.Column(db.Date)
    removal_date = db.Column(db.Date)
    removal_reason = db.Column(db.Text)
    sale_date = db.Column(db.Date)
    sale_price = db.Column(db.Float)
    mother_plant_id = db.Column(db.Integer)
    picture = db.Column(db.String(150))
    supplements = db.Column(db.String(150))
    co2 = db.Column(db.Boolean)
    species_information = db.Column(db.Text)
    aquarium_care = db.Column(db.Text)
    feeding_nutrition = db.Column(db.Text)

    aquarium = db.relationship('Aquarium', backref='plants')

    def __repr__(self):
        return f'<Plant {self.common_name}>'
